# 🚀 QUICK START GUIDE

## CSS Not Loading? Use These Files:

### ✅ RECOMMENDED: Standalone Files (Guaranteed to Work)
These files have CSS embedded and will display perfectly when opened:

- **index-standalone.html** - Main homepage (OPEN THIS ONE FIRST)
- **grade-k-2-standalone.html** - K-2 curriculum
- **grade-3-5-standalone.html** - 3-5 curriculum  
- **grade-6-8-standalone.html** - 6-8 curriculum
- **grade-9-12-standalone.html** - 9-12 curriculum

**Just double-click any of these files and they will display with full styling!**

---

### 📁 Original Files (For Web Hosting)
These require all files to be in the same folder:

- index.html
- grade-k-2.html (etc.)
- styles.css
- script.js

**Use these when:**
- Uploading to a web server
- Deploying to Netlify/GitHub Pages
- Hosting on your website

---

## 🎯 For Cognia Conference

**For Live Presentation:**
Open `index-standalone.html` in your browser

**For USB Distribution:**
Include BOTH versions:
- Standalone files (for guaranteed display)
- Original files (for web deployment)

---

## 🌐 For Web Deployment

Use the ORIGINAL files (index.html, styles.css, etc.):
1. Upload ALL files to your web host
2. Keep them in the same directory
3. Point to index.html

The standalone files are larger but work anywhere.
The original files are smaller and better for web hosting.

---

## ❓ Still Having Issues?

Try opening in a different browser:
- Chrome (recommended)
- Firefox
- Edge
- Safari

All styling should display with the standalone files!
